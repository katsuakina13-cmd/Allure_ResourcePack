Allure + Crop & Kettle + four resource pack additions (Minecraft Java 26.3)

PRIVATE TEST BUILD — DO NOT PUBLICLY REUPLOAD THIS MERGED ZIP.

Made by combining user-provided resource packs, preserving original Allure pack metadata and icon.
Latest provided assets take precedence when paths collide.
Dramatic Skys was excluded at the user's request.

Components:
- Allure original ResourcePack.zip (contains existing Beautiful Enchanted Books assets)
- Crop & Kettle v1.3.17
- Optimized Bushy Leaves (B1uberri): https://modrinth.com/resourcepack/fancyfast-bushy-leaves
- Beautiful Enchanted Books v9.0.0 (Arkadya)
- Better Lanterns v1.4.0 (Nico4play)
- Dramatic Skys Demo v1.5.3.36.6 (thebaum64): https://modrinth.com/resourcepack/dramatic-skys
- Fresh Animations v1.11.2 (FreshLX): https://modrinth.com/resourcepack/fresh-animations

Compatibility and usage:
- Minecraft Java Edition 26.3 resource pack format 97.1.
- Fresh Animations needs OptiFine or Entity Model Features + Entity Texture Features on each player's client.
- Dramatic Skys full effect needs a compatible client-side custom sky mod (Nuit/Skyboxify/OptiFine).
- Beautiful Enchanted Books source release is tagged MC 26.1.2; in-game behavior on 26.3 needs verification.
- Texture pack files are Java-only; this ZIP does not port the content to Minecraft Bedrock.
- Author restrictions prohibit public reuploads of modified/merged packs without permission.
- Do not upload this ZIP to a public GitHub repo or host it for distribution to players without obtaining applicable permissions.

Files deliberately not replaced:
- pack.mcmeta and pack.png (preserve Allure identity)
- assets/minecraft/texts/splashes.txt from Dramatic Skys (not part of sky visuals; contains promotional messages)
